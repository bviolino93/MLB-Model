MLB Edge v1.0.3 — MANUAL MARKET + DATE

Production moneyline model. Underlying model logic is unchanged from v1.0.0/v1.0.2.

UX changes:
- Restores slate date selection for today through the next 14 days.
- The Odds API is NEVER called automatically on page load, rerun, date change, or free refresh.
- Only the explicit "Load / Refresh Live Odds" button calls The Odds API and can consume credits.
- Before live odds are loaded, every modeled game remains selectable in MODEL ONLY mode.
- Single Game and Full Slate modes are preserved.
- Every modeled game remains selectable.
- Full Slate shows favorite/underdog card mix and warns when all official qualifiers are underdogs.
- No historical Odds API endpoint is used by this production app.

Deploy:
Replace app.py AND model.py. Keep your existing Streamlit ODDS_API_KEY secret. requirements.txt is unchanged.
