MLB Edge v1.0.5 — Smart Card Selection

PURPOSE
This is a production UX/selection-layer update. It does NOT alter the underlying Pitcher 2.0 + offense/platoon + lineup model probabilities, calibration, market pull workflow, or Odds API behavior.

SMART CARD RULES
- Official Bet: generally requires >=10% model edge, >=8% EV, and the existing production BET/BEST BET guardrail.
- Secondary: generally 7.5%–10% edge with >=5% EV, or a play held back by the large-underdog guardrail.
- +200 or longer underdogs: Official Bet requires confirmed lineups, confidence >=82, >=15% edge, >=12% EV, and must already pass the existing production bet guardrail.
- Legacy PASS can never be upgraded by Smart Card.
- Full Slate displays at most the top 5 Official Bets.
- No forced favorite/underdog balance.

WHY
The frozen 2025 price-bucket audit showed the model was only modestly dog-heavy overall, with the strongest credible underdog evidence in +100 to +199. Edge buckets below ~7.5% were much weaker than the 10%+ zone. Smart Card therefore filters the card without changing the model itself.

ODDS API
- No automatic odds pulls.
- Date selection, mode changes, matchup selection and model-only views use zero Odds API credits.
- Single Game has its own explicit one-game odds button.
- Full Slate has a separate explicit full-slate odds button.

DEPLOY
Replacing app.py is sufficient if your current model.py is already the v1.0.4.1-compatible production model. The package also includes matching model.py and requirements.txt for a clean full replacement.
