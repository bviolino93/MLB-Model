MLB Model v1.1.2 — Advanced Totals Validation Lab

Purpose
-------
The v1.1.1 simple totals baseline failed betting validation. v1.1.2 tests a more baseball-specific totals model before any official totals bets are promoted.

Inputs
------
1) mlb_moneyline_master_2023_2025.csv
2) mlb_historical_totals_market_2023_2025.csv

Features
--------
- Point-in-time season team runs scored / allowed
- Last-10 and last-5 scoring / prevention
- Team run-environment variance and venue-side history
- Rest
- Historical starting-pitcher ERA, FIP, K/9, BB/9, HR/9, WHIP, K-BB/9
- Recent starter form, IP/start, rest, prior-start count
- Park factor
- Empirical residual distribution for Over/Under probabilities

Validation
----------
2023 train -> 2024 market-blend selection -> 2023+24 refit -> untouched 2025 holdout.
Primary promotion criterion is 2025 calibrated RMSE vs both the frozen simple baseline and the market line. ROI is secondary.

Important limitation
--------------------
Historical MLB starter identity is retrospective. This is an upper-bound starter test and does not prove starter availability at the exact odds snapshot. Weather and bullpen are deliberately excluded until the core model passes.

Odds API
--------
Zero calls / zero credits. The historical totals market is uploaded from the v1.1.1 builder.
