MLB Totals Backtest Lab v1.1.1

Purpose
- Build historical MLB totals market data because the prior historical export was moneyline-only.
- Run a strict point-in-time totals baseline: 2023 train -> 2024 validation -> untouched 2025 holdout.
- No Odds API call occurs on page load, upload, or backtest. Only the explicit historical-build button calls the API.

Inputs
1) mlb_moneyline_master_2023_2025.csv
2) ODDS_API_KEY in Streamlit secrets for the historical totals build.

Historical cost
- totals only, US region: maximum 10 credits per uncached historical snapshot.
- The existing Moneyline Master has about 547 unique 15:00 UTC snapshots, so a fresh build is about 5,470 maximum credits.
- A hard credit ceiling blocks the run if the estimate exceeds the user's cap.
- Local cache makes resume/re-run inexpensive within the same persistent runtime; download the totals CSV once complete.

Outputs
- mlb_historical_totals_market_2023_2025.csv
- mlb_totals_holdout_2025.csv
- mlb_totals_backtest_summary.csv
- mlb_totals_backtest_metrics.csv

Important
This first totals backtest is a clean point-in-time baseline using team scoring/allowing history. It is not claimed to be an exact historical replay of the live v1.1 totals heuristic. It establishes whether there is enough totals signal to justify the next baseball-specific totals model (starter/offense/park/weather). Do not promote totals to official BET labels from this baseline alone.
