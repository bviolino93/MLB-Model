MLB Edge v1.0.4 — Single-Game Odds Pull

Underlying production model is unchanged.

New odds workflow
- App open: no odds API call.
- Date change: no odds API call.
- Switching Single Game / Full Slate: no odds API call.
- Selecting a Single Game matchup: no odds API call.
- Single Game button: explicitly resolves the selected event and loads only that event's h2h odds.
- Full Slate button: explicitly loads the full MLB h2h feed.

The Odds API documents the event-list endpoint as not counting against usage quota. The event-specific odds request itself uses quota according to the provider's market/region rules.

Important credit note: with one region (US) and one market (h2h), a single-event odds request can cost the same per request as a full-slate h2h request. Single-game mode gives you control over what is loaded; if you plan to check many games, one full-slate pull can be more credit-efficient than many separate single-game refreshes.
