MLB Model v1.1.3 — Advanced Totals Integrity Audit

Purpose: stress-test the frozen v1.1.2 advanced totals signal before promotion.

Inputs:
1) mlb_moneyline_master_2023_2025.csv
2) mlb_historical_totals_market_2023_2025.csv

Tests:
- correct context <=6h, <=3h, <=1h
- scrambled 2025 starters
- opponent starters
- no starter information
- no park factor
- no recent run environment
- Over/Under, total-line, and monthly robustness segments

No Odds API calls. Historical MLB starter identities remain retrospective, so this is an integrity stress test rather than proof of exact historical lineup/starter publication timing.
